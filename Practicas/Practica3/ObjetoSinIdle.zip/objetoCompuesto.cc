#include <cstdio>
#include <iostream>
#include <GL/gl.h>
#include <GL/glut.h>
#include "ply.h"
#include "objetoCompuesto.h"
#include "cubo.h"
#include "base.h"
#include "esfera.h"

ObjetoCompuesto::ObjetoCompuesto(){
;
}

void ObjetoCompuesto::aumentaTraslacion(){traslacion++;}
void ObjetoCompuesto::disminuyeTraslacion(){if(traslacion>0) traslacion--;}
void ObjetoCompuesto::aumentaRotacion(int numero){if(numero==1){rotacion1++;}
													if(numero==2){rotacion2++;} }

void ObjetoCompuesto::disminiuyeRotacion(int numero){if(numero==1){rotacion1--;}
														if(numero==2){rotacion2--;}}

void ObjetoCompuesto::dibujar(int modo){
Base baseObjeto;	
	glPushMatrix();
		baseObjeto.dibujar(modo);
	glPopMatrix();
Esfera objetoEsfera;
	glPushMatrix();
		glTranslatef(0,traslacion,0);
		objetoEsfera.dibujar(rotacion1,rotacion2,modo);
	glPopMatrix();

}