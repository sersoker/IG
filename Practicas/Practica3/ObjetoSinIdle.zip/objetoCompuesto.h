#ifndef _OBJCOMP_H
#define _OBJCOMP_H
class ObjetoCompuesto {
private:
    int traslacion=0;
    int rotacion1=0;
    int rotacion2=0;

public:
	//constructor
   	ObjetoCompuesto();
    void dibujar(int modo);
    void aumentaTraslacion();
    void disminuyeTraslacion();
    void aumentaRotacion(int numero);
    void disminiuyeRotacion(int numero);

};
#endif