#ifndef _OBJCOMP_H
#define _OBJCOMP_H
class ObjetoCompuesto {
public:
	//constructor
   	ObjetoCompuesto();
    void dibujar(int traslacionEsfera,int rot1, int rot2,int modo);

};
#endif