#include <cstdio>
#include <iostream>
#include <GL/gl.h>
#include <GL/glut.h>
#include "ply.h"
#include "esfera.h"

Esfera::Esfera(){
;
}

void Esfera::dibujar(int grado1,int grado2,int modo){
	Oply toroide2("toroide2");
	Oply esfera2("esfera2");
	Oply cilindro2 ("cilindro2");

//Toroide interior
	glPushMatrix();	
		glTranslatef(0,5,0);
			if(modo!=3)		esfera2.dibujar20(modo);
			else			esfera2.dibujar15(modo);
	glPopMatrix();
	glPushMatrix();	
		glTranslatef(0,5,0);
		glScalef(4.5,4.5,1);
		glRotatef(grado1,1,0,0);		
		glRotatef(90,1,0,0);
			if(modo!=3)		toroide2.dibujar20(modo);
			else			toroide2.dibujar15(modo);
	glPopMatrix();

//Union toroide exterior con la base
glPushMatrix();	
	glPushMatrix();	
		glTranslatef(0,0.3,0);	
		glPushMatrix();	
				glTranslatef(5,5,0);
			glScalef(1,0.1,0.1);
			glRotatef(90,0,0,1);		
			glTranslatef(0,-0.5,0);
				if(modo!=3)			cilindro2.dibujar20(modo);
				else				cilindro2.dibujar15(modo);
		glPopMatrix();
		glPushMatrix();	
				glTranslatef(-5,5,0);
			glScalef(1,0.1,0.1);
			glRotatef(90,0,0,1);		
			glTranslatef(0,-0.5,0);
				if(modo!=3)			cilindro2.dibujar20(modo);
				else				cilindro2.dibujar15(modo);
		glPopMatrix();	
	glPopMatrix();	
//Toroide exterior	
	glPushMatrix();	
		glTranslatef(0,5,0);
		glRotatef(grado2,0,1,0);

		glScalef(2.5,2.5,1);
		glRotatef(90,1,0,0);
			if(modo!=3)				toroide2.dibujar20(modo);
			else			toroide2.dibujar15(modo);
		glPopMatrix();		
glPopMatrix();	
}