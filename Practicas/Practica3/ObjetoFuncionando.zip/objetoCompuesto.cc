#include <cstdio>
#include <iostream>
#include <GL/gl.h>
#include <GL/glut.h>
#include "ply.h"
#include "objetoCompuesto.h"
#include "cubo.h"
#include "base.h"
#include "esfera.h"

ObjetoCompuesto::ObjetoCompuesto(){
	;
}

void ObjetoCompuesto::dibujar(int traslacionEsfera,int rot1, int rot2,int modo){
	Base baseObjeto;	
	glPushMatrix();
		baseObjeto.dibujar(modo);
	glPopMatrix();
	Esfera objetoEsfera;
	glPushMatrix();
			glTranslatef(0,traslacionEsfera,0);
		objetoEsfera.dibujar(rot1,rot2,modo);
	glPopMatrix();

}