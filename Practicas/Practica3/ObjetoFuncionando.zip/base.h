#ifndef _BASE_H
#define _BASE_H


class Base {
private:
	int grado;
public:
	//Constructor
    Base();

    //Metodo dibujar del objeto
    void dibujar(int modo);

};
#endif