#ifndef _ESFE_H
#define _ESFE_H


class Esfera {
private:
	int grado;
public:
	//Constructor
    Esfera();

    //Metodo dibujar del objeto
    void dibujar(int grado1,int grado2,int modo);

};
#endif