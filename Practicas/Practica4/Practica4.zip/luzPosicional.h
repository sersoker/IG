#ifndef _LUZPOSICIONAL_H
#define _LUZPOSICIONAL_H
#include "luz.h"

class LuzPosicional: public Luz {
private:

public:
	//constructor
   	void inicia();
   	void enciendeLuz();

};
#endif