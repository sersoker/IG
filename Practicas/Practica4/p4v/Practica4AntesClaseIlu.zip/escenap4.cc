#include <cstdio>
#include <iostream>
#include <GL/gl.h>
#include <GL/glut.h>
#include "ply.h"
#include "escenap4.h"


Escenap4::Escenap4(){
	;
}

void Escenap4::dibujar(int modo){
// Web materiales: http://www.real3dtutorials.com/tut00008.php
// Material blanco
GLfloat ambienteBlanco[] = { 0.1,0.18725,0.1745, 1.0};  
GLfloat difusaBlanco[] = { 0.396,0.74151,0.69102, 0.0};  
GLfloat especularBlanco[] = { 0.297254,0.30829,0.306678, 1.0};
//Material negro
GLfloat ambienteNegro[] = 	{ 0.1, 	0.1, 	0.1, 	0.0};  
GLfloat difusaNegro[] = 	{ 0.1,  0.1, 	0.1, 	1.0};  
GLfloat especularNegro[] = 	{ 1.0,	1.0,	1.0,	1.0};



//***********PEONES***************//
//Peon negro, con brillo
    glMaterialfv(GL_FRONT,GL_AMBIENT,ambienteBlanco);
    glMaterialfv(GL_FRONT,GL_DIFFUSE,difusaBlanco);
    glMaterialfv(GL_FRONT,GL_SPECULAR,especularBlanco);
    //glMaterialf(GL_FRONT,GL_SHININESS,38.4);
		glPushMatrix();
	   		glTranslatef(0,0,0);
			glutSolidSphere (2.0, 16, 16) ;
		glPopMatrix();			
		glPushMatrix();
			glTranslatef(5,0,0);
			glScalef(2,2,2);
			peon.dibujarN(modo);
		glPopMatrix();		

//***********PEONES*************** //
//Peon negro, con brillo
    glMaterialfv(GL_FRONT,GL_AMBIENT,ambienteNegro);
    glMaterialfv(GL_FRONT,GL_DIFFUSE,difusaNegro);
    glMaterialfv(GL_FRONT,GL_SPECULAR,especularNegro);
    glMaterialf(GL_FRONT,GL_SHININESS,38.4);	
    		glPushMatrix();
			glTranslatef(-5,0,0);
			glScalef(2,2,2);
			peon.dibujarN(modo);
		glPopMatrix();	
}


/*
// Material blanco
GLfloat ambienteBlanco[] = { 0.1,0.18725,0.1745, 1.0};  
GLfloat difusaBlanco[] = { 0.396,0.74151,0.69102, 0.0};  
GLfloat especularBlanco[] = { 0.297254,0.30829,0.306678, 1.0};
// Material metalico
GLfloat ambienteMetalico[] = { 0.19225,0.19225,0.19225, 1.0};  
GLfloat difusaMetalico[] = { 0.50754,0.50754,0.50754 , 1.0}; 
GLfloat especularMetalico[] = { 0.508273,0.508273,0.508273, 1.0};
// Material madera
GLfloat ambienteMadera[] = { 0.0 , 0.0 ,0.0 , 1.0};
GLfloat difusaMadera[] = { 1.0 ,1.0 , 1.0 , 1.0};
GLfloat especularMadera[] = { 1.0 , 1.0 , 1.0, 1.0};
// Material brillo negro
GLfloat ambienteNegro[] = 	{ 0.0, 	0.0, 	0.0, 	1.0};  
GLfloat difusaNegro[] = 	{ 0.01, 0.01, 	0.01, 	1.0};  
GLfloat especularNegro[] = 	{ 0.5, 	0.5, 	0.5, 	1.0};


//***********PEONES*************** //
//Peon negro, con brillo
    glMaterialfv(GL_FRONT,GL_AMBIENT,ambienteNegro);
    glMaterialfv(GL_FRONT,GL_DIFFUSE,difusaNegro);
    glMaterialfv(GL_FRONT,GL_SPECULAR,especularNegro);
    glMaterialf(GL_FRONT,GL_SHININESS,38.4);

//************ LATA COCACOLA************** //
    glEnable(GL_TEXTURE_2D); 
    glMaterialfv(GL_FRONT,GL_AMBIENT,ambienteMetalico);
    glMaterialfv(GL_FRONT,GL_DIFFUSE,difusaMetalico);
    glMaterialfv(GL_FRONT,GL_SPECULAR,especularMetalico);
    glMaterialf(GL_FRONT,GL_SHININESS,51.2);
	glPushMatrix();
	/*glScalef(10,10,10);
		cuerpoLata.dibujarN(modo);
		culoLata.dibujarN(modo);
		tapaLata.dibujarN(modo);
	* /glPopMatrix();
 	
//Peon blanco, sin brillo
    glMaterialfv(GL_FRONT,GL_AMBIENT,ambienteBlanco);
    glMaterialfv(GL_FRONT,GL_DIFFUSE,difusaBlanco);
    glMaterialfv(GL_FRONT,GL_SPECULAR,especularBlanco);
	glPushMatrix();
		glTranslatef(5,0,5);
		//peon.dibujarN(modo);
	glPopMatrix();

//Peon de madera, con brillo	
	glEnable(GL_TEXTURE_2D); 
    glMaterialfv(GL_FRONT,GL_AMBIENT,ambienteMadera);
    glMaterialfv(GL_FRONT,GL_DIFFUSE,difusaMadera);
    glMaterialfv(GL_FRONT,GL_SPECULAR,especularMadera);
    glMaterialf(GL_FRONT,GL_SHININESS,20.0);
	glPushMatrix();
		glTranslatef(5,0,10);
		//peon.dibujarN(modo);
	glPopMatrix();

*/