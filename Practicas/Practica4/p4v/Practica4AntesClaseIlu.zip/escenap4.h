#ifndef _ESP4_H
#define _ESP4_H
#include "orevolucion.h"
#include "ply.h"
#include "cubo.h"

class Escenap4 {
private:
	//Identificadores para las texturas
	GLuint textura_coca, textura_madera;
	Orev peon=			Orev("p4/perfil",6,1);
	Orev cuerpoLata=	Orev("p4/lata-pcue",6,1);
	Orev culoLata=		Orev("p4/lata-pinf",6,1);
	Orev tapaLata=		Orev("p4/lata-psup",6,1);
	bool normalesCalculadas=true;

public:
	//constructor
   	Escenap4();
    void dibujar(int modo);

};
#endif