#ifndef _ESP4_H
#define _ESP4_H

class Luz {
private:
	GLfloat Ambiente[] = 	{ 0.0,0.0,0.0,0.0 };	
	GLfloat Difusa[] = 		{ 0.0,0.0,0.0,0.0 };	
	GLfloat Especular[] = 	{ 0.0,0.0,0.0,0.0 };		
	GLfloat Posicion[] = 	{ 0.0,0.0,0.0,0.0 };

	int alfa=0;
	int beta=0;

	bool direccional=false;
	
public:
	//constructor
   	Luz(){;}
   	void iniciaPosicional();
   	void iniciaDireccional();
   	void aumentax();
   	void aumentay();
   	void disminuyex();
   	void disminuyey();


};
#endif