#include <cstdio>
#include <iostream>
#include <GL/gl.h>
#include <GL/glut.h>
#include "luz.h"


void Luz::iniciaPosicional(){
	GLfloat posAmbient[] = { 0.75, 0.75, 0.75, 1.0 };	GLfloat posDiffuse[] = { 1.0, 1.0, 1.0, 1.0 };	
	GLfloat posSpecular[] = { 1.0, 1.0, 1.0, 1.0 };		GLfloat posPosition[] = { 0.0, 0.0, 1.0, 0.0 };
	
	Ambiente	=	posAmbient;
	Difusa 		= 	posDiffuse;	
	Especular 	= 	posSpecular;		
	Posicion 	= 	posPosition;

	glLightfv (GL_LIGHT0, GL_AMBIENT, Ambiente);
	glLightfv (GL_LIGHT0, GL_DIFFUSE, Difusa);
	glLightfv (GL_LIGHT0, GL_SPECULAR, Especular);
	glLightfv (GL_LIGHT0, GL_POSITION, Posicion); 

}

void Luz::iniciaDireccional(){
   GLfloat ambienteDir[] = {0.5,0.5,0.5,1.0};   GLfloat difusaDir[] = {0.8,0.8,0.8,1.0};   
   GLfloat especularDir[] = {0.9,0.9,0.9,1.0};	GLfloat posDir[]={0.0,0.0,1.0,0.0};
	
	Ambiente	=	ambienteDir;
	Difusa 		= 	difusaDir;	
	Especular 	= 	especularDir;		
	Posicion 	= 	posDir;

	glLightfv (GL_LIGHT0, GL_AMBIENT, Ambiente);
	glLightfv (GL_LIGHT0, GL_DIFFUSE, Difusa);
	glLightfv (GL_LIGHT0, GL_SPECULAR, Especular);
	glLightfv (GL_LIGHT0, GL_POSITION, Posicion); 

	direccional=true;
}

void Luz::aumentax(){
	if(direccional){
		alfa++;
	}
	GLfloat posDir[]={luzAlfa,luzBeta,1.0,0.0};
	Posicion 	= 	posDir;
	glLightfv (GL_LIGHT0, GL_POSITION, Posicion); 

}

void Luz::aumentay(){
	if(direccional){
		beta++;
	}
	GLfloat posDir[]={luzAlfa,luzBeta,1.0,0.0};
	Posicion 	= 	posDir;
	glLightfv (GL_LIGHT0, GL_POSITION, Posicion); 
}

void Luz::disminuyex(){
	if(direccional){
		alfa--;
	}
	GLfloat posDir[]={luzAlfa,luzBeta,1.0,0.0};
	Posicion 	= 	posDir;
	glLightfv (GL_LIGHT0, GL_POSITION, Posicion); 
}

void Luz::disminuyey(){
	if(direccional){
		beta--;
	}
	GLfloat posDir[]={luzAlfa,luzBeta,1.0,0.0};
	Posicion 	= 	posDir;
	glLightfv (GL_LIGHT0, GL_POSITION, Posicion); 	
}
